import logo from './logo.svg';
import './App.css';
import RollingDice from './Component/RollingDice';

function App() {
  return (
    <div className="App">
     <RollingDice/>
    </div>
  );
}

export default App;
